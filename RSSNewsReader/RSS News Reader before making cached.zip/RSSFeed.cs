﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RSSNewsReader
{
    /// <summary>
    /// One loaded RSS Feed
    /// </summary>
    public class RSSFeed
    {
        string _url;
        System.Collections.ArrayList _items;

        public RSSFeed(string url)
        {
            _url = url;
            _items = new System.Collections.ArrayList();
        }

        public void AddItem(RSSItem item)
        {
            _items.Add(item);
        }

        public System.Collections.ArrayList Items
        {
            get
            {
                return _items;
            }
        }

        public string url
        {
            get
            {
                return _url;
            }
        }

        /// <summary>
        /// Marks the identified Item as read.
        /// </summary>
        /// <param name="readItem"></param>
        public void MarkAsRead(RSSItem readItem)
        {
            foreach (RSSItem item in _items)
            {
                if (item.Url == readItem.Url)
                {
                    item.IsRead = true;
                    break;
                }
            }
        }
        
        /// <summary>
        /// When loading an RSS Feed, call this after loading the items
        /// so each one is correctly marked read or not.
        /// </summary>
        /// <param name="rd"></param>
        public void IdentifyReadItems(ReadDatabase rd)
        {
            foreach (RSSItem item in _items)
            {
                item.IsRead = rd.IsRead(item);
            }
        }
    }

}
