﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// RSS News Reader
//  Simple RSS news reading application for screenreader users.
//  3.0.0   Feb     First beta.
//  3.0.1   27 Feb  Fixed news items not opening web page.
//  3.0.2   6 Mar   Loads defaults first time from http://www.webbie.org.uk/rssnewsreader/default.opml
//  3.0.3   2 Apr   Fixed adding RSS feeds, delete item menu item, command line.
//                  Added Rename option for feeds. 
//
//  Note:
//      Microsoft.VisualBasic.Logging.Log.WriteException(ex, System.Diagnostics.TraceEventType.Error, "Exception in Main(): " + ex.Message);   

namespace RSSNewsReader
{
    /// <summary>
    /// RSS News Reader
    /// </summary>
    public partial class frmMain : Form
    {

        /// <summary>
        /// Feeds is an OPML file defining my subscribed feeds.
        /// </summary>
        private System.Xml.XmlDocument _Feeds;

        /// <summary>
        /// For internationalisation.
        /// </summary>
        private I18N _I18N;

        /// <summary>
        /// The feed currently loaded
        /// </summary>
        RSSFeed _CurrentFeed;

        /// <summary>
        /// Records which items are deleted/removed.
        /// </summary>
        private ReadDatabase _readDatabase;
        
        public frmMain()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // Normal WebbIE I18N code.
            this._I18N = new I18N();
            this._I18N.DoForm(this);
            // Load the user-subscribed list of feeds.
            this._Feeds = new System.Xml.XmlDocument();
            if (System.IO.File.Exists(Application.UserAppDataPath + "\\feeds.opml"))
            {
                this._Feeds.Load(Application.UserAppDataPath + "\\feeds.opml");
            }
            else
            {
                try
                {
                    this._Feeds.Load("http://www.webbie.org.uk/rssnewsreader/default.opml");
                }
                catch
                {
                    // Failed to load latest default feeds from server, use local copy.
                    this._Feeds.Load(Application.StartupPath + "\\default.opml");
                }
            }
            // Load the "read items" file.
            this._readDatabase = new ReadDatabase(Application.UserAppDataPath);

            // Open any OPML file that's provided and add it to the existing list.
            if (Environment.GetCommandLineArgs().Length > 1)
            {
                // Been passed an OPML file, presumably.
                string opmlFile = Environment.GetCommandLineArgs()[1];
                string url = "";
                for (int i = 1; i < Environment.GetCommandLineArgs().Length; i++)
                {
                    url += Environment.GetCommandLineArgs()[i] + " ";
                }
                ImportOPML(url);
            }
            
            // Display the current feeds.
            DisplayFeeds();
            if (lstFeeds.Items.Count > 0 && RSSNewsReader.Properties.Settings.Default.SelectedFeedIndex < lstFeeds.Items.Count - 1)
            {
                lstFeeds.SelectedIndex = RSSNewsReader.Properties.Settings.Default.SelectedFeedIndex;
            }
        }

        /// <summary>
        /// Iterate through the feeds and display them. 
        /// </summary>
        private void DisplayFeeds()
        {
            this.lstFeeds.Items.Clear();
            foreach (System.Xml.XmlNode outline in this._Feeds.DocumentElement.SelectNodes("body/outline"))
            {
                // It's tempting to be clever and add the outline elements directly to the list 
                // control, then implement my own DrawItem to render the content. But that's 
                // more complicated, so I won't. Oh, I can just override .ToString()!
                lstFeeds.Items.Add(outline.Attributes.GetNamedItem("title").Value.ToString());
            }
        }

        private void lstFeeds_Click(object sender, EventArgs e)
        {
            FeedSelected();
        }

        /// <summary>
        /// A feed has been selected from the lstFeeds list. Show the news items.
        /// </summary>
        private void FeedSelected()
        {
            if (lstFeeds.SelectedIndex < 0 || lstFeeds.Items.Count == 0)
            {
                return;
            }

            lblStatus.Text = _I18N.GetText("Getting news...");
            lstItems.Items.Clear();
            
            // First save any read/hidden items.
            _readDatabase.WriteItems(this._CurrentFeed);
            
            // Now get the new feed XML file
            System.Xml.XmlDocument currentFeed = new System.Xml.XmlDocument();
            this._CurrentFeed = new RSSFeed(this._Feeds.DocumentElement.SelectNodes("body/outline")[lstFeeds.SelectedIndex].Attributes.GetNamedItem("xmlUrl").Value);
            System.Windows.Forms.Application.DoEvents();
            System.Windows.Forms.Application.DoEvents();
            System.Windows.Forms.Application.DoEvents();
            System.Windows.Forms.Application.DoEvents();
            System.Windows.Forms.Application.DoEvents();

            try
            {
                currentFeed.Load(this._CurrentFeed.url);
            }
            catch (System.Net.WebException wbEx)
            {
                lblStatus.Text = wbEx.Message;
                return;
            }
            catch (System.Xml.XmlException xmlEx)
            {
                lblStatus.Text = xmlEx.Message;
                return;
            }

            // We've got this far, so the feed XML hasn't failed to parse or load.
            if (currentFeed.DocumentElement.Name == "feed")
            {
                // Atom feed
                System.Xml.XmlNamespaceManager nm = new System.Xml.XmlNamespaceManager(currentFeed.NameTable);
                nm.AddNamespace("sugar", "http://www.w3.org/2005/Atom");
                foreach (System.Xml.XmlNode item in currentFeed.DocumentElement.SelectNodes("//sugar:entry", nm))
                {
                    RSSItem rssItem = new RSSItem(item, RSSItem.RSSType.Atom, this._CurrentFeed.url);
                    this._CurrentFeed.AddItem(rssItem);
                    System.Windows.Forms.Application.DoEvents();
                }
            }
            else
            {
                // RSS feed
                foreach (System.Xml.XmlNode item in currentFeed.DocumentElement.SelectNodes("//item"))
                {
                    RSSItem rssItem = new RSSItem(item, RSSItem.RSSType.RSS, this._CurrentFeed.url);
                    this._CurrentFeed.AddItem(rssItem);
                    System.Windows.Forms.Application.DoEvents();
                }
            }

            // Work out which items are read or not.
            this._CurrentFeed.IdentifyReadItems(this._readDatabase);

            // Now add each item to the list iff it's not counted as "read" in the read database.
            foreach (RSSItem item in this._CurrentFeed.Items)
            {
                if (!item.IsRead)
                    lstItems.Items.Add(item);
            }
            if (lstItems.Items.Count == 0)
            {
                lstItems.Items.Add(_I18N.GetText("No news items"));
                lblStatus.Text = _I18N.GetText("No news items");
            }
            else
            {
                lblStatus.Text = lstItems.Items.Count + " " + _I18N.GetText("items") + " - " + lstFeeds.Text;
            }
            lstItems.SelectedIndex = 0;
            lstItems.Focus();
        }

        private void lstItems_Click(object sender, EventArgs e)
        {
            OpenItem();
        }

        /// <summary>
        /// Open the item indicated by lstItems.SelectedIndex
        /// </summary>
        private void OpenItem()
        {
            if (lstItems.SelectedIndex < 0)
                return;

            RSSItem rssItem = (RSSItem)lstItems.Items[lstItems.SelectedIndex];
            string url = rssItem.Url;
            if (url == "")
            {
                lblStatus.Text = _I18N.GetText("Failed to open story!");
            }
            else
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = proc.StartInfo;
                startInfo.UseShellExecute = true;
                startInfo.FileName = url;
                proc.Start();
            }
        }

        private void mnuFileImport_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            ofd.CheckFileExists = true;
            ofd.DefaultExt = "opml";
            ofd.Filter = "OPML files|*.opml";
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                ImportOPML(ofd.FileName);
                DisplayFeeds();
            }
        }

        /// <summary>
        /// Imports an OPML file, adding any feeds not already in the list.
        /// </summary>
        /// <param name="filename"></param>
        private void ImportOPML(string filename)
        {
            System.Xml.XmlDocument newFeedDoc = new System.Xml.XmlDocument();
            try
            {
                newFeedDoc.Load(filename);
            }
            catch (System.Xml.XmlException xmlEx)
            {
                MessageBox.Show(this, xmlEx.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            catch (System.IO.FileNotFoundException fnfEx)
            {
                MessageBox.Show(this, fnfEx.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            int added = 0;
            foreach (System.Xml.XmlNode outlineNode in newFeedDoc.DocumentElement.SelectNodes("body/outline"))
            {
                string href = outlineNode.Attributes.GetNamedItem("xmlUrl").Value;
                if (this._Feeds.DocumentElement.SelectNodes("body/outline[@xmlUrl=\"" + href + "\"]").Count == 0)
                {
                    // This feed doesn't exist, add it. 
                    System.Xml.XmlNode importedFeedNode = this._Feeds.ImportNode(outlineNode, true);
                    this._Feeds.DocumentElement.SelectSingleNode("body").AppendChild(importedFeedNode);
                    added++;
                }
            }
            if (added > 0)
            {
                // Need to sort!
                SortFeeds();
            }
            this.lblStatus.Text = _I18N.GetText("Imported") + " " + added + " " + _I18N.GetText("new feeds.");
            DisplayFeeds();
        }

        /// <summary>
        /// Sort the feed list (which is an OPML file) by title.
        /// </summary>
        private void SortFeeds()
        {
            if (this._Feeds.DocumentElement.SelectNodes("body/outline").Count < 2)
                return;

            bool swapped = true;
            while (swapped)
            {
                swapped = false;
                for (int i = 0; i < this._Feeds.DocumentElement.SelectNodes("body/outline").Count - 1; i++)
                {
                    System.Xml.XmlNode firstNode = this._Feeds.DocumentElement.SelectNodes("body/outline")[i];
                    System.Xml.XmlNode secondNode = this._Feeds.DocumentElement.SelectNodes("body/outline")[i + 1];
                    string firstTitle = firstNode.Attributes.GetNamedItem("title").InnerText;
                    string secondTitle = secondNode.Attributes.GetNamedItem("title").InnerText;
                    if (string.Compare(firstTitle, secondTitle, true, System.Globalization.CultureInfo.CurrentCulture) > 0)
                    {
                        // Need to swap.
                        swapped = true;
                        System.Xml.XmlNode tempNode = this._Feeds.DocumentElement.SelectSingleNode("body").RemoveChild(secondNode);
                        this._Feeds.DocumentElement.SelectSingleNode("body").InsertBefore(tempNode, firstNode);
                    }
                }
            }
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Save the feeds we're using.
            this._Feeds.Save(Application.UserAppDataPath + "\\feeds.opml");
            // Save any read/hidden items.
            this._readDatabase.WriteItems(_CurrentFeed);
            // Save what's read
            this._readDatabase.Save();
            // Save the current feed
            RSSNewsReader.Properties.Settings.Default.SelectedFeedIndex = lstFeeds.SelectedIndex;
            RSSNewsReader.Properties.Settings.Default.Save();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeedSelected();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstFeeds.SelectedIndex < lstFeeds.Items.Count - 1)
            {
                lstFeeds.SelectedIndex++;
                FeedSelected();
            }
            else
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstFeeds.SelectedIndex > 0)
            {
                lstFeeds.SelectedIndex--;
                FeedSelected();
            }
            else
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
        }

        /// <summary>
        /// Creates an outline node in the feed document, populates it with
        /// the values provided, adds it, sorts the document, and updates the
        /// display of feeds. 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="title"></param>
        /// <param name="websiteUrl"></param>
        private void AddFeed(string xmlUrl, string title, string websiteUrl)
        {
            //if (title.Length == 0)
            //{
            //    throw new ArgumentException("Missing title attribute for new feed");
            //}
            System.Xml.XmlNode newOutline = this._Feeds.CreateElement("outline");
            System.Xml.XmlAttribute attr;
            attr = this._Feeds.CreateAttribute("title");
            attr.Value = title;
            newOutline.Attributes.SetNamedItem(attr);
            attr = this._Feeds.CreateAttribute("text");
            attr.Value = title;
            newOutline.Attributes.SetNamedItem(attr);
            attr = this._Feeds.CreateAttribute("type");
            attr.Value = "rss";
            newOutline.Attributes.SetNamedItem(attr);
            attr = this._Feeds.CreateAttribute("xmlUrl");
            attr.Value = xmlUrl;
            newOutline.Attributes.SetNamedItem(attr);
            attr = this._Feeds.CreateAttribute("htmlUrl");
            attr.Value = websiteUrl;
            newOutline.Attributes.SetNamedItem(attr);
            this._Feeds.DocumentElement.SelectSingleNode("body").AppendChild(newOutline);
            SortFeeds();
            DisplayFeeds();
            lblStatus.Text = _I18N.GetText("Added:") + " " + title;
            lstFeeds.SelectedIndex = lstFeeds.Items.Count - 1;
        }

        /// <summary>
        /// Delete the currently-selected feed, if there is one.
        /// </summary>
        private void DeleteSelectedFeed()
        {
            if (lstFeeds.SelectedIndex != -1)
            {
                System.Xml.XmlNode outlineNode = this._Feeds.DocumentElement.SelectNodes("body/outline")[lstFeeds.SelectedIndex];
                string url = this._Feeds.DocumentElement.SelectNodes("body/outline")[lstFeeds.SelectedIndex].Attributes.GetNamedItem("xmlUrl").Value;
                this._readDatabase.RemoveFeed(url);
            
                this._Feeds.DocumentElement.SelectSingleNode("body").RemoveChild(outlineNode);
                if (this._Feeds.DocumentElement.SelectNodes("body/outline").Count == 0)
                {
                    lstFeeds.Items.Clear();
                }
                else
                {
                    if (lstFeeds.SelectedIndex == lstFeeds.Items.Count - 1)
                    {
                        lstFeeds.SelectedIndex = lstFeeds.Items.Count - 2;
                    }
                    int selected = lstFeeds.SelectedIndex;
                    DisplayFeeds();
                    lstFeeds.SelectedIndex = selected;
                    //Don't do this: why do you want to load the
                    // next feed? FeedSelected();
                }
            }
            else
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
        }

        private void deleteFeedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteSelectedFeed();
        }

        private void lstFeeds_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.deleteFeedToolStripMenuItem.Enabled = (lstFeeds.SelectedIndex != -1);
            this.renameFeedToolStripMenuItem.Enabled = this.deletedItemsToolStripMenuItem.Enabled;
        }

        private void addFeedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string newUrl = Microsoft.VisualBasic.Interaction.InputBox(_I18N.GetText("Enter URL:"), Application.ProductName);
            if (newUrl.Length == 0)
                return;
            this.staMain.Text = "";
            if (!newUrl.ToLowerInvariant().StartsWith("http"))
            {
                newUrl = "http://" + newUrl;
            }
            //The MSDN documentation says it's best to create an XmlTextReader through .Create
            //rather than = new XmlTextReader. However, if you do it through new, you get an
            //XmlTextReader that doesn't choke on malformed XML, and if you do it through
            //.Create you choke on malformed XML. So clearly new is better!
            System.Xml.XmlTextReader xtr;
            try
            {
                xtr = new System.Xml.XmlTextReader(newUrl);
            }
            catch (System.UriFormatException ufe)
            {
                // Not a valid URL. Skip trying to analyse.
                MessageBox.Show(_I18N.GetText("Invalid URL:") + " " + ufe.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            catch (Exception ex)
            {
                // Unknown error - File Not Found, possibly - display and quit.
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string newFeedUrl = "";
            string rootNodeName = "";
            bool finishedSearching = false;
            bool readOK = true;
            while (!xtr.EOF && !finishedSearching && readOK)
            {
                try
                {
                    readOK = xtr.Read();
                    if (xtr.NodeType == System.Xml.XmlNodeType.Element)
                    {
                        string elementName = xtr.Name.ToLowerInvariant();
                        // If this is the first node then it is the root node. 
                        // Remember the name so that we know what type of document
                        // the user has given us - Atom, RSS, or a web page to
                        // search.
                        System.Diagnostics.Debug.Print("Node:" + elementName);
                        if (rootNodeName.Length == 0)
                        {
                            rootNodeName = elementName;
                        }
                        if (rootNodeName == "html")
                        {
                            // This is an HTML file, scan it for RSS feeds.
                            if (elementName == "link")
                            {
                                // Got a link: is it valid?
                                if (xtr.HasAttributes)
                                {
                                    string href = xtr.GetAttribute("href");
                                    string rel = xtr.GetAttribute("rel");
                                    if (rel.ToLowerInvariant() == "alternate" && href != "")
                                    {
                                        // Got it!
                                        newFeedUrl = href;
                                        finishedSearching = true;
                                    }
                                }
                            }
                        }
                        else if (rootNodeName == "feed" || rootNodeName == "rss")
                        {
                            // It's an RSS/Atom feed, go ahead and add it 
                            // without further checking, and stop reading
                            // this document.
                            newFeedUrl = newUrl;
                            finishedSearching = true;
                        }
                    }
                }
                catch
                {
                    //Parsing error from the web page or XML = very common, carry on going
                    //until we find something useful.
                }
                System.Windows.Forms.Application.DoEvents();
            }
            xtr.Close();

            // OK, so we've examined the url the user gave us. Found anything?
            if (newFeedUrl == "")
            {
                // Failed to find anything!
                MessageBox.Show(_I18N.GetText("No RSS news feeds found"), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // OK, try getting it. 
                System.Xml.XmlTextReader newFeed = new System.Xml.XmlTextReader(newFeedUrl);
                string newTitle = "";
                string newWebsiteUrl = "";
                bool foundTitleAndUrl = false;
                bool nextNodeIsTitle = false;
                bool nextNodeIsWebsiteUrl = false;
                readOK = true;
                while (!newFeed.EOF && !foundTitleAndUrl && readOK)
                {
                    try
                    {
                        readOK = newFeed.Read();
                        if (newFeed.NodeType == System.Xml.XmlNodeType.Element)
                        {
                            System.Diagnostics.Debug.Print("Node:" + newFeed.Name.ToLowerInvariant());
                            if (newFeed.Name.ToLowerInvariant() == "title")
                            {
                                if (newTitle == "")
                                {
                                    nextNodeIsTitle = true;
                                }
                            }
                            else if (newFeed.Name.ToLowerInvariant() == "link")
                            {
                                if (newWebsiteUrl == "")
                                {
                                    nextNodeIsWebsiteUrl = true;
                                }
                            }
                        }
                        else if (newFeed.NodeType == System.Xml.XmlNodeType.Text)
                        {
                            if (nextNodeIsTitle)
                            {
                                newTitle = newFeed.Value;
                                nextNodeIsTitle = false;
                            }
                            if (nextNodeIsWebsiteUrl)
                            {
                                newWebsiteUrl = newFeed.Value;
                                nextNodeIsWebsiteUrl = false;
                            }
                        }
                    }
                    catch
                    {
                        // Error in XML, very common, carry on.
                    }
                    if (newTitle.Length > 0 && newWebsiteUrl.Length > 0)
                    {
                        foundTitleAndUrl = true;
                    }
                    System.Windows.Forms.Application.DoEvents();
                }
                newFeed.Close();
                // OK, add to lists!
                if (foundTitleAndUrl)
                {
                    // TODO check we got the new RSS data okay.
                    AddFeed(newFeedUrl, newTitle, newWebsiteUrl);
                    try
                    {
                        // Submission of RSS feed to database.
                        newTitle = System.Net.WebUtility.HtmlEncode(newTitle);
                        newUrl = System.Net.WebUtility.HtmlEncode(newUrl);
                        System.Net.HttpWebRequest wr = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://data.webbie.org.uk/newRSSFeed.php?title=" + newTitle + "&url=" + newFeedUrl + "&language=" + this._I18N.GetLanguage());
                        wr.KeepAlive = false;
                        wr.Method = System.Net.WebRequestMethods.Http.Get;
                        wr.ContentType = "text/html";
                        wr.AllowAutoRedirect = true;
                        wr.GetResponse();
                    }
                    catch
                    {
                        // Failed to connect and write feed information: record why to error log.
                        System.Diagnostics.EventLog.WriteEntry(Application.ProductName + " " + Application.ProductVersion, "Failed to submit new feed registration to WebbIE (" + newUrl + ")");
                    }
                }
                else
                {
                    // Not found a feed.
                    staMain.Text = this._I18N.GetText("0 feeds found.");
                }
            }
        }

        private void mnuFileExport_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.SaveFileDialog sfd = new System.Windows.Forms.SaveFileDialog();
            sfd.CheckPathExists = true;
            sfd.AddExtension = true;
            sfd.DefaultExt = "opml";
            sfd.Filter = "OPML Files|*.opml";
            sfd.FileName = "RSS News Feeds.opml";
            if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    _Feeds.Save(sfd.FileName);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.EventLog.WriteEntry(Application.ProductName + " " + Application.ProductVersion, "Failed to export OPML file: " + ex.Message);
                }
            }
        }

        private void openFeedWebsiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Xml.XmlNode currentFeed = this._Feeds.DocumentElement.SelectNodes("body/outline")[lstFeeds.SelectedIndex];
            if (currentFeed.Attributes.GetNamedItem("httpUrl") == null)
            {
                // Missing http value
                Microsoft.VisualBasic.Interaction.Beep();
            }
            else
            {
                System.Diagnostics.Process.Start(currentFeed.Attributes.GetNamedItem("httpUrl").InnerText);
            }
        }

        private void lstItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && lstItems.SelectedIndex > -1)
            {
                MarkCurrentItemAsRead();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                // Go to feeds list.
                lstFeeds.Focus();
            }
            else if (e.KeyCode == Keys.Up && this.lstItems.SelectedIndex == 0)
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
            else if (e.KeyCode == Keys.Down && this.lstItems.SelectedIndex == this.lstItems.Items.Count - 1)
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
        }

        /// <summary>
        /// Mark the currently-selected item as read - that is, remove it from
        /// display.
        /// </summary>
        private void MarkCurrentItemAsRead()
        {
            RSSItem rssItem = (RSSItem)lstItems.Items[lstItems.SelectedIndex];
            this._CurrentFeed.MarkAsRead(rssItem);
            int index = lstItems.SelectedIndex;
            FeedSelected();
            if (index < lstItems.Items.Count - 1 && lstItems.Items.Count > 0)
                lstItems.SelectedIndex = index;
        }
        
        private void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstFeeds_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                FeedSelected();
            }
            else if (e.KeyCode == Keys.Delete)
            {
                DeleteSelectedFeed();
            }
            else if (e.KeyCode == Keys.Up && this.lstFeeds.SelectedIndex == 0)
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
            else if (e.KeyCode == Keys.Down && this.lstFeeds.SelectedIndex == this.lstFeeds.Items.Count - 1)
            {
                Microsoft.VisualBasic.Interaction.Beep();
            }
        }

        private void deletedItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RSSNewsReader.Properties.Settings.Default.ViewDeletedItems = !RSSNewsReader.Properties.Settings.Default.ViewDeletedItems;
            FeedSelected();
        }

        private void mnuWebsiteDeleteallwebsitefeeds_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(_I18N.GetText("Do you really want to delete every RSS news feed?"), Application.ProductName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Remove every feed.
                this._Feeds.DocumentElement.SelectSingleNode("body").RemoveAll();
                this.lstFeeds.Items.Clear();
                this.lstItems.Items.Clear();
                this._readDatabase.ClearAll();
                this._CurrentFeed = null;
            }
        }

        private void mnuHelpManual_Click(object sender, EventArgs e)
        {
            _I18N.ShowHelp();
        }

        private void mnuHelpAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, Application.ProductName + "\t" + Application.ProductVersion, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lstItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                OpenItem();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkCurrentItemAsRead();
        }

        private void renameFeedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RenameSelectedFeed();
        }

        private void RenameSelectedFeed()
        {
            if (lstFeeds.SelectedIndex < 0)
                return;

            string newName = Microsoft.VisualBasic.Interaction.InputBox("Enter a new name for the feed:", Application.ProductName, lstFeeds.Text);
            if (newName.Length > 0)
            {
                // Open the feed node
                System.Xml.XmlNode outline = this._Feeds.DocumentElement.SelectNodes("body/outline")[this.lstFeeds.SelectedIndex];
                //Rename
                outline.Attributes.GetNamedItem("title").Value = newName;
                outline.Attributes.GetNamedItem("text").Value = newName;
                //Reload display of feeds
                SortFeeds();
                DisplayFeeds();
                for (int i = 0; i < this.lstFeeds.Items.Count; i++)
                {
                    if (this.lstFeeds.Items[i].ToString().StartsWith(newName))
                    {
                        this.lstFeeds.SelectedIndex = i;
                        break;
                    }
                }
                lstFeeds.Focus();
            }
        }

        private void mnuFeeds_Click(object sender, EventArgs e)
        {

        }
     
    }

}
