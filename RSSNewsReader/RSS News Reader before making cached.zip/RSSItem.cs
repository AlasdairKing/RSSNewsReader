﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RSSNewsReader
{
    /// <summary>
    /// One item in an RSS feed
    /// </summary>
    public class RSSItem
    {
        private string _title;
        private string _feedUrl;
        private string _itemUrl;
        private bool _isRead;
        private string _pubDate;
        private string _contents;

        /// <summary>
        /// Whether RSS or Atom
        /// </summary>
        public enum RSSType
        {
            /// <summary>
            /// This is an Atom feed
            /// </summary>
            Atom,
            /// <summary>
            /// This is an RSS feed
            /// </summary>
            RSS
        }

        public RSSItem(string title, string itemUrl, string feedUrl, string pubDate, string contents)
        {
            _title = title;
            // Do character substitutions to catch character escape sequences that have ended up in the data
            // probably because of an error on the website. I'm sure this list could be extended, but 
            // quotation marks and dashes are the main offenders.
            _title = title.Replace("&#8217;", "'").Replace("&#8211;", "-").Replace("&#8216", "'").Replace("&#8220", "\"").Replace("&#8221", "\"").Replace("&amp;", "&") ;
            _feedUrl = feedUrl;
            _itemUrl = itemUrl;
            DateTime dt;
            if (DateTime.TryParse(pubDate, out dt))
            {
                _pubDate = dt.ToLongDateString();
                if (_pubDate.StartsWith("0"))
                {
                    // Leading zeros look sucky.
                    _pubDate = _pubDate.Substring(1, _pubDate.Length - 1);
                }
            }
            else
            {
                _pubDate = "";
            }
            _contents = TrivialParse(contents);
        }

        /// <summary>
        /// Parse the HTML into text very stupidly.
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        private string TrivialParse(string html)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            Char[] htmlChars = html.ToCharArray();
            int parseState = 0; // 0 = output, 1 = don't output, 2 = don't output this character but output next.
            for (int i = 0; i < htmlChars.Length; i++)
            {
                if (htmlChars[i] == '<')
                {
                    parseState = 1;
                }
                else if (htmlChars[i] == '>')
                {
                    parseState = 2;
                }
                else if (parseState == 0)
                {
                    sb.Append(htmlChars[i]);
                }
                if (parseState == 2)
                {
                    parseState = 0;
                }
            }
            return sb.ToString();
        }

        public string contents
        {
            get
            {
                return _contents;
            }
        }

        public string feedUrl
        {
            get
            {
                return _feedUrl;
            }
        }

        public override string ToString()
        {
            string name;
            if (_pubDate.Length == 0)
            {
                name = _title;
            }
            else
            {
                name = _title + " (" + _pubDate + ")";
            }
            if (_contents.Length == 0)
            {
                return name;
            }
            else
            {
                return name + " \"" + _contents + "\"";
            }
        }


        public string Url
        {
            get
            {
                return _itemUrl;
            }
        }

        public bool IsRead
        {
            get
            {
                return _isRead;
            }
            set
            {
                _isRead = value;
            }
        }
    }
}
