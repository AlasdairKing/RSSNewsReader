﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RSSNewsReader
{
    public class ReadDatabase
    {
        System.Collections.ArrayList _read;
        string _AppPath;

        public ReadDatabase(string userDataPath)
        {
            _AppPath = userDataPath;
            _read = new System.Collections.ArrayList();
            if (System.IO.File.Exists(_AppPath + "\\read.txt"))
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(_AppPath + "\\read.txt", Encoding.UTF8);
                while (!sr.EndOfStream)
                {
                    string readEntry = sr.ReadLine().Trim();
                    if (readEntry.Length > 0)
                    {
                        _read.Add(readEntry);
                    }
                }
                sr.Close();
            }
        }


        /// <summary>
        /// Call this before terminating the class to save the database to disk.
        /// </summary>
        public void Save()
        {
            System.IO.StreamWriter sw = new System.IO.StreamWriter(_AppPath + "\\read.txt", false, Encoding.UTF8);
            for (int i = 0; i < _read.Count; i++)
            {
                sw.WriteLine(_read[i]);
            }
            sw.Close();
        }

        public bool IsRead(RSSItem itemNode)
        {
            //System.Diagnostics.Debug.Print("CHECKING IF READ:" + itemNode.Url);
            string id = itemNode.feedUrl + "*" + itemNode.Url;
            for (int i = 0; i < _read.Count; i++)
            {
                if ((string)this._read[i] == id)
                {
                    return true;
                }
            }
            return false;
        }

        public void ClearAll()
        {
            _read = new System.Collections.ArrayList();
        }

        /// <summary>
        /// Call this when you are deleting a feed from your collection: it will
        /// remove the read/unread information for the feed. 
        /// </summary>
        /// <param name="feed"></param>
        public void RemoveFeed(RSSFeed feed)
        {
            for (int i = _read.Count - 1; i >= 0; i--)
            {
                if (_read[i].ToString().StartsWith(feed.url))
                {
                    _read.RemoveAt(i);
                }
            }
        }

        /// <summary>
        /// Call this before you clear the list or exit the program to save read.
        /// </summary>
        /// <param name="items"></param>
        /// <param name="feedUrl"></param>
        public void WriteItems(RSSFeed feed)
        {
            if (feed == null)
                return;
            else if (feed.Items.Count == 0)
                return;
            System.Collections.ArrayList itemIds = new System.Collections.ArrayList();
            foreach (RSSItem item in feed.Items)
            {
                string id = feed.url + "*" + item.Url;
                itemIds.Add(id);
                if (item.IsRead)
                {
                    // Add to _read array.
                    bool found = false;
                    for (int i = 0; i < _read.Count; i++)
                    {
                        if ((string)_read[i] == id)
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        _read.Add(id);
                        System.Diagnostics.Debug.Print("READ:" + id);
                    }
                }
            }
            // Now clean up the _read array, removing items that are no longer items
            // in the feed.
            for (int i = _read.Count - 1; i > -1; i--)
            {
                string savedId = _read[i].ToString();
                if (savedId.StartsWith(feed.url))
                {
                    // Item from this feed. Is it still an item?
                    bool stillItem = false;
                    for (int j = 0; j < itemIds.Count; j++)
                    {
                        System.Diagnostics.Debug.Print("CHECK:" + (string)itemIds[j]);
                        if (savedId == (string)itemIds[j])
                        {
                            // Yes.
                            stillItem = true;
                            break;
                        }
                    }
                    if (!stillItem)
                    {
                        System.Diagnostics.Debug.Print("DELETING:" + savedId);
                        _read.RemoveAt(i);
                    }
                }
            }
        }
    }
}
